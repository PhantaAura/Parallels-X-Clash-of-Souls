PARALLELS X: CLASH OF SOULS — U7A / U7B / U8 / U9 / U10 BATCH
Target baseline: agent/u4-u6-golden-gate @ d84d6e944c6b90822da461b33e418f57b504fe43
Batch ID: u7-u10-20260811

WHAT THIS PACKAGE DOES

U7A — Cinematic Foundation
- Adds shared RuntimeSession cutscene actions: MoveTo, FaceActor, PlayAnimation, LookAt,
  CameraTrack, CameraFocus, TriggerWorldEvent, Wait, Dialogue, Expression.
- Retrofists key Chapter 1 scenes without rewriting the Chapter 1 story.
- Keeps the exact 0.75-second Legacy idle and dedicated combat_retreat intact.
- Builds the seamless Tournament entrance staging path.

U7B — Ability / Rrvvfo Presentation
- Object Swap is a literal position exchange, NOT a dash.
- Adds sparse free-use physical swap props: 225-unit range, 4.5-second cooldown, 20 Energy.
- Required story swaps retain authority and do not inherit the free-use cooldown.
- Object Swap = gold/yellow target + brief gold/translucent phase + dual ghosts.
- Lens = purple, with a short recoverable blindness presentation after use.
- Shots of Agony remains unavailable in Chapter 1. Rendering is future-proofed only.

U7 GOLDEN GATE
- Source gates are checked during the updater.
- Acceptance is NOT considered green until Chapter 1 is rechecked on Mac/Linux/real Old 3DS.
- This batch may stage U8-U10 source in the same working branch because the user explicitly asked
  for one cumulative batch, but the acceptance gate still remains documented and locked.

U8 — Tournament Hub / Continuous Story
- Adds rrvvfo_ch2 as the next internal content/save boundary.
- Game::advanceScene continues directly into it without a menu.
- Adds shared tournament_grounds / tournament_arena maps and tournament presentation stages.
- Arrival walks through the gate; Sage rejoins while moving.
- Adds the Lost Bracket hub-introduction sequence.

U9 — Minimum Complete Tournament Loop
- Uses the same px_core / RuntimeSession / CombatSystem.
- Adds data-only arena encounter definitions, not a Tournament Engine.
- Required progression: practice brawl, Hamual, Daniel, Bark vs Pouki spectator set piece,
  Wade, then Plouke final.
- Official fights use stocks/ring-outs; Plouke remains the canonical tournament winner.
- Adds Tournament Card progression/save data and +1/+2/+3 stat bonus selection.
- Cracked Ring remains investigation-only in Chapter 2.

U10 — Tournament Golden Polish
- Adds tournament festival/tournament/final/cleanup world-life states.
- Adds waiting/medical/photo/bracket/race dressing and more crowd silhouettes.
- Makes Tournament Card readable on macOS and Old 3DS bottom screen.
- Fixes Chapter-2 saves so reset Chapter-1 runtime fields cannot overwrite completed Chapter-1 flags.
- Removes player-facing hardcoded Chapter 1 header from normal macOS Story UI.
- Keeps fixed opponent identities/levels; no silent scaling, no official-match Run command.

HOW TO APPLY

1. Start from the existing U6 working repository, or reset a new local branch from:
   origin/agent/u4-u6-golden-gate
2. Run apply_update7_10.py with --milestone all.
3. Run scripts/verify-update7-10.py (the updater also runs it automatically).
4. Build macOS and Old 3DS separately.
5. Do NOT call the batch accepted until the milestone gates in MILESTONE_GATES.md pass.

The updater does NOT automatically run the old giant regression test suite. Build/import and
acceptance testing are deliberately separate so a stale developer assertion cannot prevent a DMG/3DSX build.
