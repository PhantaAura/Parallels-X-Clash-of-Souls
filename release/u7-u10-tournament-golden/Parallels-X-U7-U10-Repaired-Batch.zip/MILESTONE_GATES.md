# Parallels X U7–U10 Milestone Locks

Permanent milestone sequence:

**BUG CHECK → exact 1:1 simplification when provably safe → REGRESSION CHECK → CONTINUE**

## U7A — Cinematic Foundation

Must retain one shared runtime. Cutscene actions are content-driven and platform-independent.
No Chapter 1 story rewrite. No Sage Object Swap implication. Exact Legacy 0.75s idle and dedicated
`combat_retreat` stay locked. Reduced Motion must remain respected by presentation shells.

## U7B — Ability / Character Presentation

Object Swap is literal physical exchange, never a dash. Free-use props are short-range and sparse;
they cannot cross progression blockers. Free-use cooldown is long enough to prevent spam, while required
puzzle swaps are not punished by it. Object Swap is gold; Lens is purple and briefly blinds Rrvvfo;
Shots of Agony stays unavailable in Chapter 1.

## U7 Golden Regression Gate — hard acceptance block

Before declaring U7 accepted, run Chapter 1 end-to-end on the shared build:
- full / quick / skip tutorial routes
- river swap
- Main / Forest / Cliff
- relay
- transport two-swap rescue
- runaway cart
- optional roadside story/pass return
- collapse detour
- checkpoint
- Lens direct route + southern detour
- Sign That Points Back
- outskirts arrival
- seamless Tournament handoff
- save/load/manual save/checkpoint restart/accessibility
- Mac, Linux, real Old 3DS

U8 source may be staged in this cumulative batch, but this gate is still the acceptance authority.

## U8 — Tournament Hub / Continuous Story

No menu at the internal Chapter 1→2 boundary. Tournament arrival, registration, market, practice,
spectator, contestant and arena gate are authored districts in the same shared engine. The Lost Bracket
teaches the hub. Sage rejoins in motion at the entrance.

## U9 — Tournament Core

Same `px_core`, same RuntimeSession, same CombatSystem. Minimum complete required loop only:
practice → Hamual → Daniel → Bark/Pouki spectator beat → Wade → Plouke final. Official fights are
first-to-three stocks with KO/ring-out stock loss. Tournament Card is saved. Cracked Ring does not reveal
or fight a saboteur in Chapter 2. Plouke always wins the tournament story.

## U10 — Tournament Golden

Intermission/world states read differently without spawning a second hub simulation. Tournament Card is
readable on Mac and 3DS. Completed Chapter-1 flags survive Chapter-2 saves. Accessibility and platform
reductions never change rules. Final acceptance includes Mac/Linux/real Old 3DS smoke, save/load,
suspend/resume, performance/memory, text readability and deformation checks.
