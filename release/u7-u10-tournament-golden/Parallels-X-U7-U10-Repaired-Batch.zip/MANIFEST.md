# U7–U10 Batch Manifest

Baseline: `d84d6e944c6b90822da461b33e418f57b504fe43`

The batch is intentionally cumulative and idempotent. `--milestone 7a`, `7b`, `8`, `9`, or `10`
applies every required earlier stage through that target; `--milestone all` applies all five.

Key architecture locks:
- one `px_core`
- no Tournament Engine / Chapter 2 Engine
- internal chapters are content/save boundaries, not normal Story menus
- Chapter 1 remains intact
- Object Swap is literal object exchange
- Lens is purple + brief blindness
- Shots of Agony is future-only and remains unavailable in Chapter 1
- exact 0.75s Legacy idle is protected
- dedicated `combat_retreat` is protected

The generated `scripts/verify-update7-10.py` is a fast source invariant checker. It is not a replacement
for platform builds or real Old 3DS acceptance.
