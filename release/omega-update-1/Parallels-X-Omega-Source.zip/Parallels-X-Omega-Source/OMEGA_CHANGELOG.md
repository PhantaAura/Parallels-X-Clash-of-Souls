# OMEGA source changelog

## Milestone A — Rrvvfo + combat feel

- Re-authors Rrvvfo locomotion/combat motion from the supplied sprite-sheet language.
- Keeps exact Legacy 0.75 s hub idle.
- Adds combat-ready and combat-relax transitions.
- Active combat stationary state is fighting stance, never hub idle.
- Dedicated combat advance and combat retreat; no reverse-play hub run.
- Adds hard-land presentation.
- Keeps Perfect Block clip connected to the actual Perfect Block event.
- Preserves the shared 39-joint model/rig and garment-repair geometry/weights.
- Fire Blast: 22 Energy, 1.05 s cooldown, 15 damage, 9 Guard damage.
- Replay becomes non-persistent and imports QoL/seen-cutscene history read-only.
- QoL settings no longer reset just because Story/Fight/Training is restarted.

### Milestone A regression findings fixed

- Reverse-playing the hub run was still being used as combat retreat.
- Replay launch path could overwrite Continue and also lost seen-cutscene state.
- Unsafe optional-arena save coordinates could be serialized as road coordinates.
- Newly authored animation clips could exist without runtime selection; transition/event wiring was checked explicitly.

## Milestone B — Chapter 1 route parity + persistence

- Existing Chapter 1 stays intact.
- Main Road gets four post-Fire-Blast work/navigation beats.
- Forest gets four sequential blue bells.
- Cliff gets five sequential airborne ledges.
- Adds ~18 s / ~36 s escalating route guidance.
- Transport recovery becomes a two-sided Object Swap rescue.
- Final roadblock becomes direct Lens vs physical southern detour.
- Southern detour state persists as `world_delight_southern_detour` plus Chapter 1 flags.
- Route progress, relay state, Cliff mask, dynamic relay positions and Fire-clear state persist through save/reload.
- Nearby authored NPCs turn toward Rrvvfo when he approaches for interaction.

### Milestone B regression findings fixed

- Repeated numeric route-state flags are erased/replaced so stale earlier values cannot win on reload.
- Saving after the final relay swap no longer risks restoring into a gate-release softlock.
- New route state has explicit regression assertions and checkpoint restoration coverage.

## Milestone C — persistence/platform professionalism

- Schema 5 prefers stable checkpoint IDs when resolving Story scenes and retains numeric index fallback for migration.
- Restart From Checkpoint uses a captured safe scene/manual-load snapshot instead of only resetting scene-local variables.
- Primary saves are semantically validated before they are trusted or copied over a good backup.
- Standalone/replay pause menu exposes Accessibility & QoL.
- Combat message verbosity can cycle FULL / IMPORTANT / OFF.
- Linux uses XDG/home user data by default, with development override support.
- Linux adds Shift Dash and mouse Light/Block mapping.
- Linux release packaging includes the required Rrvvfo PXSKEL.
- Mac/Linux/3DS front-end reduced-motion state inherits the saved preference.
- Mac/3DS migrate to `save-v5` paths while retaining older save fallbacks.
- 3DS build syncs the freshly cooked shared Rrvvfo PXSKEL into ROMFS before compilation.

### Milestone C regression findings fixed

- Parseable-but-invalid primary saves could bypass backup fallback.
- Writers could replace a valid backup with a corrupt primary.
- 3DS ROMFS could silently keep an older animation asset after desktop recook.

## Intentionally outside OMEGA

- 3DS/model visual-resolution/anti-pixelation pass: **Graphics update #2**.
- Pure no-cut performance work: **Optimize update #3**.
- Chapter 2.
- Fake implementations of browser Fire Blast projectile speed/radius/clash power where the current shared projectile model has no corresponding fields.
