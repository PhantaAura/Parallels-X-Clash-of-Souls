# Codex handoff — OMEGA

Apply this only to a clean checkout of `v0.4H.5-candidate` (`851b8613fac6451f62ef492ad0ee454622096f63`).

```sh
cd /path/to/Parallels-X-Clash-of-Souls
git checkout v0.4H.5-candidate
python3 /path/to/Parallels-X-Omega-Source/apply_omega.py . --check-only
python3 /path/to/Parallels-X-Omega-Source/apply_omega.py .

python3 scripts/author-rrvvfo-core-animations.py \
  assets/characters/rrvvfo/rrvvfo-dev.glb \
  assets/characters/rrvvfo/rrvvfo-idle.animation.json \
  assets/characters/rrvvfo/rrvvfo-core.animation.json

python3 scripts/cook-character-glb.py \
  assets/characters/rrvvfo/rrvvfo-dev.glb \
  assets/characters/rrvvfo/rrvvfo-dev.pxskel \
  --settings assets/characters/rrvvfo/rrvvfo-dev.materials.json \
  --animations assets/characters/rrvvfo/rrvvfo-core.animation.json

./scripts/test.sh
./scripts/build-linux.sh
./scripts/build-macos.sh
./scripts/build-3ds.sh
```

Do not upload/push anything merely because this handoff exists. First run the tests/builds and inspect failures. Preserve the existing Chapter 1; OMEGA is an in-place polish/parity update. Do not start Chapter 2. Do not fold the separate Graphics or Optimize update into this pass.

Important manual review after tests:

- Hub standing uses `idle`; active combat standing uses `fighting_stance`.
- Combat entry uses `combat_ready`; forward/back movement uses `combat_advance`/`combat_retreat` with positive playback speed.
- Rrvvfo run looks like an actual sprint and not a casual walk.
- Check all newly authored clips for jacket/shirt/arm deformation.
- Main route = 4 work beats; Forest = 4 bells; Cliff = 5 ledges.
- Transport requires both the outbound wheel swap and the return-anchor swap.
- Final roadblock offers Lens or southern detour and persists the detour.
- Replay never changes the Continue save and still knows which cutscenes were seen.
- Restart From Checkpoint restores a real stable scene/manual-load state.
- Linux package contains the Rrvvfo PXSKEL and launches from the packaged layout.
- 3DS ROMFS Rrvvfo PXSKEL is byte-identical to the freshly cooked desktop PXSKEL before final packaging.

Known intentional limitation: Fire Blast cost/cooldown/damage/Guard damage are updated, but browser speed=500/radius=25/clash-power=1.3 need a real projectile-object field/simulation port rather than being faked through the generic melee-style `AttackDefinition` geometry.
