# Parallels X: Clash of Souls 3.0R — OMEGA Source Overlay

## Baseline

This package targets **exactly**:

- GitHub tag: `v0.4H.5-candidate`
- Commit: `851b8613fac6451f62ef492ad0ee454622096f63`

It is a **source overlay**, not a compiled build and not a full repository mirror. The patcher is intentionally strict: it expects audited 0.4H.5 source anchors and refuses to continue if they no longer match. No GitHub files are changed by this package.

## Three-update plan

This ZIP is **Update 1: OMEGA** only.

1. OMEGA — gameplay, Rrvvfo animation/character feel, Chapter 1 parity/professionalism, save/replay/platform correctness.
2. Graphics — separate later pass, especially cleaner 3DS visual/model presentation. Not included here.
3. Optimize — separate later pass that removes no content/features/visual intent and focuses only on performance/runtime/asset/code efficiency. Not included here.

**Chapter 1 is not removed or replaced.** OMEGA extends and polishes the existing Chapter 1 in place. Chapter 2 is not added here.

## Apply

From a clean checkout of the exact candidate:

```sh
git checkout v0.4H.5-candidate
python3 /path/to/Parallels-X-Omega-Source/apply_omega.py . --check-only
python3 /path/to/Parallels-X-Omega-Source/apply_omega.py .
```

The first command verifies the audited anchors without writing. If it refuses, do not force-apply it to a different source tree.

## Regenerate Rrvvfo's shared animation asset

OMEGA replaces the authored animation source, not the model geometry/weights. Keep the existing repaired GLB and exact Legacy six-frame idle source, then regenerate:

```sh
python3 scripts/author-rrvvfo-core-animations.py \
  assets/characters/rrvvfo/rrvvfo-dev.glb \
  assets/characters/rrvvfo/rrvvfo-idle.animation.json \
  assets/characters/rrvvfo/rrvvfo-core.animation.json

python3 scripts/cook-character-glb.py \
  assets/characters/rrvvfo/rrvvfo-dev.glb \
  assets/characters/rrvvfo/rrvvfo-dev.pxskel \
  --settings assets/characters/rrvvfo/rrvvfo-dev.materials.json \
  --animations assets/characters/rrvvfo/rrvvfo-core.animation.json
```

The patched 3DS build script copies this freshly cooked PXSKEL into ROMFS before building so Mac/Linux/3DS use the same shared Rrvvfo animation set.

## Test and build after applying

```sh
./scripts/test.sh
./scripts/build-linux.sh
./scripts/build-macos.sh
./scripts/build-3ds.sh
```

Run the platform commands only on systems with the required toolchains. `build-macos.sh` needs macOS/Apple SDK. `build-3ds.sh` needs devkitPro/devkitARM/libctru/Citro2D/Citro3D.

## OMEGA gameplay/feel scope

OMEGA makes Rrvvfo's animation language use the supplied sprite sheet as pose/silhouette/energy authority rather than copying impossible 2D distortions literally. Hub standing stays `idle`; active fights use `combat_ready -> fighting_stance`. Combat locomotion gets dedicated `combat_advance` and `combat_retreat`; retreat no longer reverse-plays the hub run. The authored set also adds `combat_relax` and `hard_land`, keeps the exact 0.75-second Legacy idle, and revises the run into a stronger forward-driving sprint.

The existing Chapter 1 route scene is expanded toward browser 2.9A.40.7.2R parity: four Main Road work beats after Fire Blast, four Forest bells, five Cliff ledges, ~18/~36-second guidance, a two-sided transport swap rescue, and a Lens-vs-southern-detour finish with persistent detour state. Native marker coordinates are authored for the current 3.0R map because the exact browser route coordinates are not present in the audited repository documents.

The patch also isolates Chapter Replay from the real Story save, carries seen-cutscene/QoL data into Replay, upgrades to schema 5 with stable checkpoint-ID resolution, gives Restart From Checkpoint a stable scene snapshot, hardens backup validation, preserves safe road position around the optional arena, makes QoL accessible in standalone modes, fixes Linux Shift/mouse controls/save paths/package assets, and keeps the regenerated Rrvvfo PXSKEL synchronized into 3DS ROMFS.

## Fire Blast status

OMEGA applies the currently representable Chapter 1 browser values:

- 22 Energy
- 1.05 s cooldown
- 15 damage
- 9 Guard damage

The browser also specifies projectile speed 500, radius 25, and clash power 1.3. The current shared combat model does not yet expose a real projectile-object definition carrying those three independent fields, so this package **does not fake them by abusing melee attack geometry**. They remain a real follow-up item for the projectile simulation rather than a false claim of complete parity.

## Validation status / limitations

This package's Python source passes local syntax compilation. It has **not** been compiled as the whole C++ project in this environment because the complete GitHub checkout and binary assets are not mounted locally here. Codex/the local repository must run the test/build commands above after applying.

The Graphics update and pure Optimize update are intentionally not folded into OMEGA. Real Old 3DS hardware remains the final authority for frame pacing, memory, suspend/resume, text readability, model deformation, and control feel.

## Reference

`notes/rrvvfo-animation-sprite-reference.jpeg` is the supplied sprite-sheet reference for OMEGA animation attitude/poses. Use it as a visual motion reference, not as a requirement to reproduce physically impossible 2D distortion on the 3D skeleton.
